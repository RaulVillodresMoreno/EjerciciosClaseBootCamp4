package com.nttdata.bootcamp.webfluxmicro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxMicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
